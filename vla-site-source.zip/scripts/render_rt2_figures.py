"""Render RT-2 v1 author-reported tables and an original architecture diagram."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from xml.sax.saxutils import escape

ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
colors=['#9cabc4','#7086a8','#245ce2','#137c79']
def rows(name):
    with (ROOT/'dist/data'/name).open() as f:return list(csv.DictReader(f))
def finish(fig,name):
    fig.savefig(ROOT/'dist/assets'/name,bbox_inches='tight',facecolor='white');plt.close(fig)
def bars(ax,data,labels,title):
    y=np.arange(len(data));ax.barh(y,data,color=colors[-len(data):],height=.56)
    ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xticks([0,25,50,75,100]);ax.set_axisbelow(True);ax.grid(axis='x',color='#e3e8f0');ax.tick_params(length=0,pad=8);ax.set_title(title,loc='left',fontweight='bold',pad=16);ax.set_xlabel('Success (%)')
    for i,v in enumerate(data):ax.text(min(v+1.5,96),i,f'{v:g}',va='center',color='#192638')
r=rows('rt2-overall.csv');r=[r[i] for i in [2,3,4,5]]
labels=['RT-1','MOO','RT-2 PaLI-X 55B','RT-2 PaLM-E 12B']
fig,axes=plt.subplots(1,2,figsize=(12,3.7),layout='constrained')
for ax,key,title in zip(axes,['seen','unseen_average'],['Seen tasks','Unseen average']):bars(ax,[float(x[key]) for x in r],labels,title)
fig.suptitle('RT-2 v1 · Table 6 | Author-reported values; no uncertainty reported',fontsize=11,color='#64748b')
finish(fig,'rt2-overall.svg')
r=rows('rt2-ablations.csv');fig,axes=plt.subplots(1,2,figsize=(12,3.7),layout='constrained')
bars(axes[0],[float(x['unseen_average']) for x in r[:3]],['From scratch','Fine-tuning','Co-fine-tuning'],'PaLI-X 5B')
bars(axes[1],[float(x['unseen_average']) for x in r[3:]],['Fine-tuning','Co-fine-tuning'],'PaLI-X 55B')
fig.suptitle('RT-2 v1 · Table 8 | Unseen average; no 55B from-scratch result',fontsize=11,color='#64748b')
finish(fig,'rt2-ablations.svg')
r=rows('rt2-emergent.csv');fig,axes=plt.subplots(1,3,figsize=(16,4.2),layout='constrained')
for ax,key,title in zip(axes,['symbol_average','reasoning_average','person_average'],['Symbol understanding','Reasoning','Person recognition']):bars(ax,[float(x[key]) for x in r],['VC-1','RT-1','PaLI-X 55B','PaLM-E 12B'],title)
fig.suptitle('RT-2 v1 · Table 7 | Category averages; excludes the CoT variant',fontsize=11,color='#64748b')
finish(fig,'rt2-emergent.svg')

svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1060 690" role="img" aria-labelledby="title desc"><title id="title">RT-2 联合训练与闭环推理</title><desc id="desc">机器人和视觉语言任务共享预训练 VLM。动作监督经编码进入模型，推理约束词表后反量化，执行并重新观察。</desc><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#7086a8"/></marker></defs><rect width="1060" height="690" fill="#fff"/><g font-family="Inter,Noto Sans SC,system-ui,sans-serif">']
def text(x,y,s,size=17,color='#192638',bold=False):
    svg.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}"'+(' font-weight="600"' if bold else '')+'>'+escape(s)+'</text>')
def box(x,y,w,h,lines,accent=False):
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{"#edf3ff" if accent else "#f7f9fc"}" stroke="{"#a9c2f5" if accent else "#dce4ef"}"/>')
    for i,line in enumerate(lines):text(x+18,y+31+i*27,line,17 if i==0 else 14,'#245ce2' if accent and i==0 else '#52637d',i==0)
def arrow(d):svg.append(f'<path d="{d}" fill="none" stroke="#7086a8" stroke-width="2" marker-end="url(#arrow)"/>')
text(34,38,'RT-2 / 联合训练与闭环推理',24,bold=True)
text(34,66,'理解重绘 · 图中共享的是训练配方，PaLI-X 与 PaLM-E 保留各自内部结构。',14,'#64748b')
text(34,106,'01 / CO-FINE-TUNING',13,'#245ce2',True)
box(34,126,258,100,['机器人示范','相机图像 + 任务指令','目标：编码后的动作序列'])
box(34,248,258,100,['视觉语言任务','图像 + 问题 / 描述任务','目标：自然语言答案'])
box(354,178,292,110,['预训练 VLM → 联合微调','PaLI-X：编码器—解码器','PaLM-E：decoder-only'],True)
arrow('M292 175H320V215H351');arrow('M292 298H320V252H351')
box(708,126,318,100,['动作 token 损失','PaLI-X：已有整数 token','PaLM-E：覆盖低频 token'])
box(708,248,318,100,['语言 token 损失','问答、图像描述等','继续保留视觉语言监督'])
arrow('M646 215H680V175H705');arrow('M646 252H680V298H705')
svg.append('<path d="M34 382H1026" stroke="#e3e8f0"/>')
text(34,420,'02 / ROBOT INFERENCE',13,'#245ce2',True)
box(34,452,208,100,['当前观测 + 指令','机器人动作任务提示','输入视觉语言上下文'])
box(290,452,216,100,['微调后的 VLM','自回归动作字段','按任务限制动作词表'],True)
box(554,452,210,100,['token → 控制量','解码与反量化','终止、位姿增量、夹爪'])
box(812,452,214,100,['机器人与控制器','应用当前一步动作','执行后重新观察'])
for x in [242,506,764]:arrow(f'M{x} 502H{x+45}')
arrow('M919 554V598H138V555')
text(414,590,'观测反馈：更新环境状态，再预测下一步',14,'#64748b')
text(34,645,'8 个字段属于当前一步；默认动作策略与额外 CoT 微调变体分别讨论。',15,'#52637d')
text(34,673,'依据：RT-2 v1，Fig. 1、§3、附录 D。概念图不指定实例的帧数、patch 数或控制单位。',13,'#64748b')
svg.append('</g></svg>');(ROOT/'dist/assets/rt2-architecture.svg').write_text(''.join(svg))
print('Rendered RT-2 architecture and three table-based figures.')
