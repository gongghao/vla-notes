"""FAST v1: plot reported data and draw explanatory codec diagrams.

No policy reproduction, inferred success rates, or invented error bars.
"""
from pathlib import Path
from xml.sax.saxutils import escape
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BLUE, TEAL, GRAY = '#245ce2', '#137c79', '#9cabc4'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'svg.fonttype': 'none',
                     'font.size': 10, 'axes.spines.top': False,
                     'axes.spines.right': False, 'axes.spines.left': False,
                     'axes.spines.bottom': False})

def read(name):
    with (ROOT / 'dist/data' / name).open() as f:
        return list(csv.DictReader(f))

def save(fig, name):
    fig.savefig(ROOT / 'dist/assets' / name, bbox_inches='tight', facecolor='white')
    plt.close(fig)

def style(ax, label):
    ax.grid(axis='x', color='#e3e8f0')
    ax.set_axisbelow(True)
    ax.tick_params(length=0, pad=8)
    ax.set_xlabel(label)

rows = read('fast-token-counts.csv')
fig, ax = plt.subplots(figsize=(11.5, 5.5), layout='constrained')
y = np.arange(len(rows))
for offset, field, label, color in [(-.17, 'naive_mean_tokens', 'Naive per-step bins', GRAY),
                                    (.17, 'fast_mean_tokens', 'FAST', BLUE)]:
    vals = [float(r[field]) for r in rows]
    ax.barh(y + offset, vals, height=.28, color=color, label=label)
    for v, p in zip(vals, y + offset):
        ax.text(v + 6, p, f'{v:g}', va='center', fontsize=10)
ax.set_yticks(y, [f"{r['dataset']} · D={r['action_dim']}, {r['control_hz']} Hz" for r in rows])
ax.set_xlim(0, 790)
ax.invert_yaxis()
style(ax, 'Mean tokens per 1-second action chunk')
ax.set_title('Table I · Comparable reconstruction error', loc='left', fontweight='bold', pad=18)
ax.legend(loc='upper left', bbox_to_anchor=(0, -.16), ncol=2, frameon=False)
save(fig, 'fast-token-counts.svg')

rows = read('fast-tokenizer-mixture.csv')
assert abs(sum(float(r['mixture_weight_percent']) for r in rows) - 100) < 1e-9
fig, axs = plt.subplots(1, 2, figsize=(11.5, 4.7), layout='constrained')
for ax, field, labels, title in [
        (axs[0], 'action_space', ['Joint', 'EE', 'CamFrame'], 'Action parameterization'),
        (axs[1], 'morphology', ['Single arm', 'Bimanual', 'Mobile'], 'Robot morphology')]:
    vals = [sum(float(r['mixture_weight_percent']) for r in rows if r[field] == label)
            for label in labels]
    ax.barh(np.arange(3), vals, height=.5, color=[BLUE, TEAL, GRAY])
    for i, v in enumerate(vals):
        ax.text(v + 1.3, i, f'{v:.1f}%', va='center')
    ax.set_yticks(np.arange(3), labels)
    ax.set_xlim(0, 65)
    ax.invert_yaxis()
    style(ax, 'Tokenizer mixture weight (%)')
    ax.set_title(title, loc='left', fontweight='bold', pad=18)
fig.suptitle('Appendix A · Our aggregation of 31 reported weights | Not policy training weights',
             fontsize=11, color='#64748b')
save(fig, 'fast-mixture.svg')

rows = read('fast-efficiency.csv')
fig, axs = plt.subplots(1, 3, figsize=(12.5, 4.5), layout='constrained')
groups = [('bussing_training_steps', 'Bussing convergence', 'Relative training steps', ['1', '≈ 1/3']),
          ('generalist_gpu_hours', 'Generalist checkpoint', 'Relative training GPU hours', ['1', '≈ 1/5']),
          ('inference_latency', 'Inference · RTX 4090', 'Latency per 1-second chunk (ms)', ['≤ 100', '≈ 750'])]
for ax, (group, title, xlabel, annotations) in zip(axs, groups):
    r = [r for r in rows if r['comparison'] == group]
    vals = [float(r['value']) for r in r]
    bars = ax.barh([0, 1], vals, height=.43, color=[GRAY, BLUE])
    if group == 'inference_latency':
        bars[0].set_hatch('///')
        bars[0].set_edgecolor('#64748b')
        ax.set_xlim(0, 1000)
        offset = 22
    else:
        ax.set_xlim(0, 1.35)
        ax.set_xticks([0, .5, 1], ['0', '0.5', '1'])
        offset = .04
    for p, v, s in zip([0, 1], vals, annotations):
        ax.text(v + offset, p, s, va='center', fontsize=10)
    ax.set_yticks([0, 1], ['pi0 / flow', 'pi0-FAST'])
    ax.invert_yaxis()
    style(ax, xlabel)
    ax.set_title(title, loc='left', fontweight='bold', pad=18)
fig.suptitle('§VI-E/F · Separate protocols | Relative ratios and approximate / upper-bound latency',
             fontsize=11, color='#64748b')
save(fig, 'fast-efficiency.svg')

class SVG:
    def __init__(self, w, h, title, desc):
        self.items = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" '
                      'role="img" aria-labelledby="title desc">'
                      f'<title id="title">{escape(title)}</title><desc id="desc">{escape(desc)}</desc>'
                      '<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" '
                      'refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#7086a8"/>'
                      '</marker></defs>'
                      f'<rect width="{w}" height="{h}" fill="white"/>'
                      '<g font-family="Inter,Noto Sans SC,system-ui,sans-serif">']

    def text(self, x, y, value, size=16, color='#192638', bold=False):
        self.items.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}"'
                          + (' font-weight="600"' if bold else '') + '>' + escape(value) + '</text>')

    def box(self, x, y, w, h, lines, kind='normal'):
        fill, stroke = {'normal': ('#f7f9fc', '#dce4ef'),
                        'blue': ('#edf3ff', '#a9c2f5'),
                        'teal': ('#eff8f7', '#99cdcb')}[kind]
        self.items.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" '
                          f'fill="{fill}" stroke="{stroke}"/>')
        for i, line in enumerate(lines):
            self.text(x + 16, y + 29 + i * 25, line, 16 if i == 0 else 14,
                      BLUE if kind == 'blue' and i == 0 else TEAL if kind == 'teal' and i == 0
                      else '#52637d', i == 0)

    def arrow(self, path, dashed=False):
        self.items.append(f'<path d="{path}" fill="none" stroke="#7086a8" stroke-width="2"'
                          + (' stroke-dasharray="6 5"' if dashed else '')
                          + ' marker-end="url(#arrow)"/>')

    def save(self, name):
        (ROOT / 'dist/assets' / name).write_text(''.join(self.items) + '</g></svg>')

d = SVG(1140, 970, 'FAST 训练与部署编码链路',
        '未来示范编码为训练标签。部署从当前观测自回归预测，再逆BPE、逆DCT和反归一化恢复近似动作块。')
d.text(34, 38, 'FAST / 动作 tokenizer 与策略，分别学习', 24, bold=True)
d.text(34, 66, '理解重绘 · DCT 与 BPE 可逆；系数取整有损。未来示范仅提供训练监督。', 14, '#64748b')
d.text(34, 106, '01 / 示范编码：动作块 → 压缩 token 标签', 17, BLUE, True)
d.box(34, 129, 300, 116, ['归一化动作 A：H × D', '各维训练数据 q1% / q99%', '沿时间轴做 DCT', '每个动作维度分别变换'], 'blue')
d.box(418, 129, 300, 116, ['系数量化 Q = round(γC)', 'γ 控制量化精度', '所有频率位置都量化', '并非固定删除高频'], 'blue')
d.box(802, 129, 304, 116, ['频率优先展开 → BPE', '仍有 H × D 个整数，再压缩', '固定词表，可变 token 长度 N', '唯一学习的编码组件：BPE'], 'blue')
d.arrow('M334 187H413')
d.arrow('M718 187H797')
d.text(34, 293, '02 / VLA 训练：观测条件 + 真实前缀 → 下一 token 的交叉熵', 17, bold=True)
d.box(34, 318, 300, 116, ['当前观测条件', '2–3 张 RGB 图像、语言', '本体状态分箱成整数文本', '没有未来真实图像／状态'])
d.box(418, 318, 300, 116, ['自回归 Transformer', '训练用真实 token 前缀', '因果 mask；teacher forcing', '更新策略模型权重'], 'blue')
d.box(802, 318, 304, 116, ['预测分布 + 标签 → CE', '目标是压缩动作 token', '并行计算各位置训练损失', 'BPE 词表与策略训练分开'])
d.arrow('M334 376H413')
d.arrow('M718 376H797')
d.arrow('M954 247V312', True)
d.arrow('M854 247V274H738V350H724', True)
d.text(586, 262, '右移的真实前缀', 12, '#64748b')
d.text(34, 489, '03 / 部署：当前观测 → 逐 token 预测 → 连续动作块', 17, TEAL, True)
d.box(34, 514, 300, 116, ['观测 → 自回归策略', '用此前预测 token 作前缀', '逐 token 生成完整序列', '推理仍有串行依赖'], 'teal')
d.box(418, 514, 300, 116, ['逆 BPE → Q：H × D', '无损恢复预测的整数串', '按已知尺寸 H、D 重排', '不是一个 token 对应一步'], 'teal')
d.box(802, 514, 304, 116, ['Q ÷ γ → 逆 DCT', '沿时间轴逐维恢复', '得到量化后的近似轨迹', '取整损失不可逆'], 'teal')
d.arrow('M334 572H413')
d.arrow('M718 572H797')
d.box(802, 687, 304, 91, ['反归一化 → 执行', '恢复平台动作单位与语义', '按任务执行窗口，再观察'], 'teal')
d.arrow('M954 632V682')
d.arrow('M954 780V824H18V572H29')
d.text(34, 867, '解码配置：H、D、γ、BPE 词表、归一化统计须已知；可变 N 不代表时长可变。', 15, '#52637d')
d.text(34, 900, 'tokenizer 重建误差与策略预测误差分开；编码频率顺序也不等于机器人执行顺序。', 14, '#64748b')
d.text(34, 935, '来源：FAST v1 §V-B、Algorithm 1、附录 C 与官方模型卡；省略起止符与边界细节。', 13, '#64748b')
d.save('fast-pipeline.svg')

d = SVG(1140, 796, '频率优先展开与教学BPE合并',
        '四频率三维整数矩阵按行展开，再用教学零串符号从12整数压为6符号。逆向合并恢复原整数串。')
d.text(34, 38, '频率优先 / 先跨维度形成低频轮廓', 24, bold=True)
d.text(34, 66, '教学例子 H=4、D=3；Z2、Z4 是解释符号，不是真实 FAST+ 词表或实验数据。', 14, '#64748b')
d.text(34, 112, '量化矩阵 Q：每行一个频率', 17, BLUE, True)
for j in range(3):
    d.text(140 + j * 66, 151, f'd={j+1}', 14, '#64748b')
matrix = [[4, -2, 1], [1, 0, 0], [0, 0, 0], [0, 0, 0]]
for k, row in enumerate(matrix):
    y = 168 + k * 52
    d.text(34, y + 31, f'k={k}', 15, BLUE if k == 0 else '#64748b')
    for j, value in enumerate(row):
        d.items.append(f'<rect x="{124+j*66}" y="{y}" width="56" height="43" rx="7" '
                       f'fill="{"#edf3ff" if k == 0 else "#f7f9fc"}" stroke="#dce4ef"/>')
        d.text(143 + j * 66, y + 28, str(value), 17)
d.text(34, 411, 'k=0：各维度的 DC / 平均项', 14, '#64748b')
d.text(34, 438, '随后 k=1、2、3，频率递增', 14, '#64748b')
d.arrow('M338 225H413')
d.box(418, 147, 688, 98, ['频率优先 / 按行展开', '[4, −2, 1] → [1, 0, 0] → [0, 0, 0] → [0, 0, 0]', '12 个整数位置：非零 4 个，零 8 个'], 'blue')
d.box(418, 282, 688, 98, ['若按动作维度 / 按列展开', '[4, 1, 0, 0] → [−2, 0, 0, 0] → [1, 0, 0, 0]', '不是论文选用的生成顺序；不同顺序改变相邻合并机会'])
d.text(34, 492, 'BPE 不改变整数值，只把常见邻接串收为可逆符号', 17, TEAL, True)
d.box(34, 519, 490, 116, ['教学合并规则', 'Z2 = [0, 0]', 'Z4 = [Z2, Z2] = [0, 0, 0, 0]', '真实词表还可合并其他常见系数组合'], 'teal')
d.box(608, 519, 498, 116, ['压缩序列：6 个教学符号', '[4, −2, 1, 1, Z4, Z4]', '逆 BPE 展开 → 原 12 个整数', '之后再重排、除尺度、逆 DCT'], 'teal')
d.arrow('M524 577H603')
d.text(34, 685, '稀疏 ≠ 短序列：零系数仍占位置；BPE 合并后才减少自回归输出数量。', 15, '#52637d')
d.text(34, 718, '“先生成低频”不意味着“先执行低频动作”；需要解码出完整动作块。', 14, '#64748b')
d.text(34, 759, '依据：FAST v1 §V-B、Algorithm 1、Fig. 4 与 §VI-D；例子仅用于说明机制。', 13, '#64748b')
d.save('fast-ordering.svg')
