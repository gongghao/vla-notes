"""ActMem-VLA v1: tables / printed figure labels and explanatory diagrams.
Source authors: Yaxin Zhao, Dianye Huang, Chenwei Wang, Chenguang Yang, Zhongliang Jiang.
Adapted note figures: CC BY-SA 4.0. No policy execution or inferred uncertainty.
"""
from pathlib import Path
import csv
from xml.sax.saxutils import escape
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
R=Path(__file__).resolve().parents[1]
BLUE,TEAL,GRAY='#245ce2','#137c79','#8d9cb3'
SRC='https://arxiv.org/html/2609.37307v1'
RIGHTS='CC BY-SA 4.0; source: Zhao, Huang, Wang, Yang and Jiang, ActMem-VLA v1; adapted by VLA Notes.'
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
def read(name):
 with (R/'dist/data'/('actmem-'+name+'.csv')).open() as f:return list(csv.DictReader(f))
def save(fig,name):
 fig.savefig(R/'dist/assets'/('actmem-'+name+'.svg'),bbox_inches='tight',facecolor='white',metadata={'Title':'ActMem-VLA: '+name,'Creator':'VLA Notes','Description':SRC,'Rights':RIGHTS});plt.close(fig)
def axis(ax,xlabel,limit=100):
 ax.set_xlim(0,limit);ax.grid(axis='x',color='#e3e8f0');ax.set_axisbelow(True);ax.tick_params(length=0,pad=8);ax.set_xlabel(xlabel)
def bars(ax,labels,values,colors,xlabel,limit=107,fmt='.1f'):
 y=np.arange(len(labels));ax.barh(y,values,color=colors,height=.53);ax.set_yticks(y,labels);ax.invert_yaxis();axis(ax,xlabel,limit)
 for i,v in enumerate(values):ax.text(v+limit*.012,i,format(v,fmt),va='center',fontsize=9)
r=read('task-limits');fig,ax=plt.subplots(figsize=(11.4,6.5),layout='constrained')
bars(ax,[x['task']+' | '+x['task_name'] for x in r],[int(x['step_limit']) for x in r],BLUE,'Episode budget (simulation control steps)',665,'.0f')
ax.axvline(600,color=TEAL,linestyle='--',linewidth=1.7,label='Standard limit: 600');ax.legend(loc='lower right',frameon=False)
fig.suptitle('Figure 4 / Eq.4 | 95th-percentile demonstration length, round up to 20, cap at 600',fontsize=11,color='#64748b');save(fig,'limits')
r=read('simulation');methods=['pi0.5','MemoryVLA','ActMem-VLA'];colors=[GRAY,TEAL,BLUE]
fig,axs=plt.subplots(1,2,figsize=(13.2,8.6),gridspec_kw={'width_ratios':[2.5,1]},layout='constrained')
tasks=[x for x in r if x['method']=='pi0.5' and x['task']!='Avg.'];y=np.arange(10)
for j,(method,color) in enumerate(zip(methods,colors)):
 rows=[x for x in r if x['method']==method and x['task']!='Avg.'];vals=[float(x['success_percent']) for x in rows];pos=y+(j-1)*.23;axs[0].barh(pos,vals,height=.21,color=color,label=method)
 for i,(posi,v) in enumerate(zip(pos,vals)):axs[0].text(v+1.0,posi,f'{v:.1f}',va='center',fontsize=8)
axs[0].set_yticks(y,[x['task']+' | '+x['task_name']+' ('+x['step_limit']+')' for x in tasks]);axs[0].invert_yaxis();axis(axs[0],'Success (%) | task-specific step limits in parentheses',109);axs[0].legend(loc='lower left',bbox_to_anchor=(0,-.12),ncol=3,frameon=False);axs[0].set_title('Ten tasks | 180 trials per task / method',loc='left',fontweight='bold')
averages=[float(next(x for x in r if x['method']==m and x['task']=='Avg.')['success_percent']) for m in methods]
bars(axs[1],methods,averages,colors,'Reported ten-task average (%)',110);axs[1].set_title('Equal task mean',loc='left',fontweight='bold')
fig.suptitle('Figure 4 printed labels | 3 training seeds x 3 evaluation seeds x 20 trials per task',fontsize=11,color='#64748b');save(fig,'simulation')
r=read('ablation');fig,axs=plt.subplots(1,4,figsize=(12.8,4.3),layout='constrained')
for ax,field,title in zip(axs,['t6_percent','t7_percent','t8_percent','reported_average_percent'],['T6 | Bowl x7','T7 | Bowl swap','T8 | Bowl rotation','Three-task mean']):
 bars(ax,['No memory','No PAE','Full model'] if ax is axs[0] else ['','',''],[float(x[field]) for x in r],[GRAY,TEAL,BLUE],'Success (%)',112);ax.set_title(title,loc='left',fontweight='bold',fontsize=10)
fig.suptitle('Table I | Single training seed; 60 trials per task | T8 favors the no-PAE variant',fontsize=11,color='#64748b');save(fig,'ablation')
r=read('sensitivity');fig,axs=plt.subplots(1,2,figsize=(12.4,5.3),layout='constrained')
x=[.3,.4,.5,.6];v=[48.3,55.0,45.0,47.2];axs[0].plot(x,v,color=BLUE,marker='o',linewidth=2);axs[0].set_ylim(0,100);axs[0].set_xlim(.27,.63);axs[0].set_xticks(x);axs[0].set_xlabel('Handover r | n=10 flow updates');axs[0].set_ylabel('Reported three-task mean success (%)');axs[0].grid(color='#e3e8f0');axs[0].set_axisbelow(True);axs[0].set_title('PAE early steps / frozen AE late steps',loc='left',fontweight='bold',fontsize=10)
for xx,vv in zip(x,v):axs[0].text(xx,vv+3,f'{vv:.1f}',ha='center',fontsize=10)
rows=[r[-1]]+r[3:7];labels=['Default: Mamba 2/1024; PAE 4','Mamba depth: 2 -> 4','Mamba width: 1024 -> 1536','PAE depth: 4 -> 2','PAE depth: 4 -> 6']
bars(axs[1],labels,[float(x['reported_average_percent']) for x in rows],[BLUE]+[GRAY]*4,'Reported three-task mean success (%)',107);axs[1].set_title('One capacity change at a time',loc='left',fontweight='bold',fontsize=10)
fig.suptitle('Table II | One training seed; task-wise rates retained in CSV | No uncertainty estimates added',fontsize=11,color='#64748b');save(fig,'sensitivity')
r=read('real-world');fig,axs=plt.subplots(1,2,figsize=(12.6,5.7),gridspec_kw={'width_ratios':[2,1]},layout='constrained')
first=[x for x in r if x['method']=='pi0.5' and x['task']!='Overall'];y=np.arange(4)
for j,(method,color) in enumerate([('pi0.5',GRAY),('ActMem-VLA',BLUE)]):
 rows=[x for x in r if x['method']==method and x['task']!='Overall'];vals=[float(x['success_percent']) for x in rows];pos=y+(j-.5)*.32;axs[0].barh(pos,vals,height=.29,color=color,label=method)
 for posi,v,row in zip(pos,vals,rows):axs[0].text(v+1.5,posi,f'{v:.0f}% ({row["successes"]}/20)',va='center',fontsize=9)
axs[0].set_yticks(y,[x['task']+' | '+x['task_name'] for x in first]);axs[0].invert_yaxis();axis(axs[0],'Success (%) | 20 trials per task',132);axs[0].legend(loc='lower left',bbox_to_anchor=(0,-.2),ncol=2,frameon=False);axs[0].set_title('Four DOBOT Nova tasks',loc='left',fontweight='bold')
rows=[x for x in r if x['task']=='Overall'];bars(axs[1],[x['method']+'\n'+x['successes']+'/80' for x in rows],[float(x['success_percent']) for x in rows],[GRAY,BLUE],'Aggregate success (%)',107,'.2f');axs[1].set_title('Exact gain: 28.75 points',loc='left',fontweight='bold',fontsize=10)
fig.suptitle('Figure 6 / Section IV-D | Task demonstrations: 50 each | No MemoryVLA real-world result reported',fontsize=11,color='#64748b');save(fig,'real-world')
class Diagram:
 def __init__(self,h,title,desc):
  self.p=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 {h}" role="img"><title>{escape(title)}</title><desc>{escape(desc)}</desc><metadata>{escape(RIGHTS+" Source: "+SRC)}</metadata><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#8090aa"/></marker></defs><rect width="1200" height="{h}" fill="white"/><style>text{{font-family:system-ui,"Noto Sans CJK SC",sans-serif;fill:#24354f}}.small{{font-size:16px;fill:#64748b}}.title{{font-size:24px;font-weight:700}}.body{{font-size:19px}}.boxhead{{font-size:20px;font-weight:650}}.arrow{{fill:none;stroke:#8090aa;stroke-width:2.5;marker-end:url(#arrow)}}</style>']
 def text(self,x,y,text,cls='body',anchor='start'):self.p.append(f'<text x="{x}" y="{y}" class="{cls}" text-anchor="{anchor}">{escape(text)}</text>')
 def box(self,x,y,w,h,title,lines,fill='#f2f6ff'):
  self.p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="{fill}" stroke="#d7e1ee"/>');self.text(x+18,y+31,title,'boxhead')
  for i,line in enumerate(lines):self.text(x+18,y+61+i*26,line,'small')
 def arrow(self,x1,y1,x2,y2):self.p.append(f'<path d="M{x1} {y1} L{x2} {y2}" class="arrow"/>')
 def path(self,d):self.p.append(f'<path d="{d}" class="arrow"/>')
 def save(self,name):(R/'dist/assets'/('actmem-'+name+'.svg')).write_text(''.join(self.p)+'</svg>')
d=Diagram(852,'ActMem-VLA: execution memory and expert handover','Mamba与PAE训练，VLM与原AE冻结，同一去噪状态交接；执行前缀再更新记忆。')
d.text(36,43,'ActMem-VLA · 记忆引导早期，冻结专家细化后期','title');d.text(36,76,'按 v1 Figure 2 / §III 理解重绘 · 基础 VLA 已先微调 · 中文改编与图：CC BY-SA 4.0','small')
d.box(36,115,310,125,'当前上下文',['外部/腕部图像 + 指令','本体状态；不是历史图像'])
d.box(407,115,330,125,'VLM · 冻结',['当前观察形成 prefix KV','相应层 KV 供专家使用'])
d.box(798,115,366,125,'已执行动作历史',['最近 s 步动作 + 递归状态','排除未执行的预测后缀'],'#edf7f5');d.arrow(346,178,407,178)
d.box(798,285,366,122,'Mamba-2 · 训练',['2 层 / 宽度 1024 → mₜ','投影为 history KV'],'#edf7f5');d.arrow(981,240,981,285)
d.box(36,443,266,130,'初始噪声 A⁰',['每次查询采样整块高斯噪声','flow time τ=0'])
d.box(366,443,380,130,'PAE · 训练',['当前 prefix KV + history KV','前4次Euler更新 → A⁰·⁴'],'#edf7f5')
d.box(810,443,354,130,'原 AE · 冻结',['当前 prefix KV + A⁰·⁴','后6次更新；无直接history KV'])
d.arrow(302,508,366,508);d.arrow(746,508,810,508)
d.path('M572 240 L572 443');d.path('M737 178 L773 178 L773 96 L1178 96 L1178 508 L1164 508');d.path('M981 407 L981 423 L656 423 L656 443')
d.text(951,89,'prefix KV → AE','small',anchor='middle')
d.box(36,640,550,120,'执行与观察',['完整动作块生成后，执行前 s≤H 步','再获得新观察，开始下一次策略查询'])
d.box(646,640,518,120,'下一次记忆更新',['只把刚执行的 s 步写入 Mamba','保留 episode 内递归状态'],'#edf7f5')
d.path('M987 573 L987 615 L310 615 L310 640');d.arrow(586,700,646,700)
d.text(36,811,'4/6 是生成迭代次数，不是机械臂执行步；动作发生记录不能独立证明操作成功。','small');d.save('architecture')
d=Diagram(739,'ActMem-VLA: two clocks and executed prefix','10次flow更新前4PAE后6AE；教学H12s4显示只有已执行4步写记忆，非实际部署超参数。')
d.text(36,43,'ActMem-VLA · 两条时间轴，两个不同的步数','title');d.text(36,76,'按 Eq.1–3 与默认配置重绘 · 中文改编与图：CC BY-SA 4.0','small')
d.text(36,127,'① 同一次动作生成：flow time τ，从噪声到动作','boxhead')
for i in range(10):
 x=36+i*113;fill='#edf7f5' if i<4 else '#f2f6ff';d.box(x,153,106,92,'PAE' if i<4 else 'AE',[f'τ={i/10:.1f}'],fill)
d.text(36,278,'A⁰ → A⁰·¹ → A⁰·² → A⁰·³ → A⁰·⁴', 'body');d.text(648,278,'→ A⁰·⁵ … → A¹：整块生成完成','body')
d.text(456,310,'τ=.4 交接中间状态，不重置噪声','small')
d.text(36,376,'② 机器人执行：只执行动作块前缀，再查询与更新记忆','boxhead')
d.text(36,410,'教学示例：H=12，s=4（原文未给具体部署 H/s）','small')
for i in range(12):
 x=36+i*94;fill='#edf7f5' if i<4 else '#f5f6f9';d.box(x,440,88,87,str(i+1),['已执行' if i<4 else '未执行'],fill)
d.box(36,568,1128,112,'记忆只能读动作 1–4',['动作 5–12 仍是预测，不能记成过去的执行；下一次查询可能改写它们','flow 更新τ与环境执行时间无相同单位；20步预算对齐也不是20Hz控制频率'])
d.save('handover')
print('Rendered five data charts and two explanatory diagrams, including source attribution and CC BY-SA metadata.')
