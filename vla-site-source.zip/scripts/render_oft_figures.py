"""Plot OpenVLA-OFT v2 report values and draw explanatory architecture SVGs.
Charts reproduce table values; no local policy results or inferred error bars.
"""
from pathlib import Path
from xml.sax.saxutils import escape
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
R=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
BLUE='#245ce2';TEAL='#137c79';GRAY='#9cabc4';ORANGE='#ad7130';PURPLE='#7855a6'
def read(name):
 with (R/'dist/data'/name).open() as f:return list(csv.DictReader(f))
def save(fig,name):
 fig.savefig(R/'dist/assets'/name,bbox_inches='tight',facecolor='white');plt.close(fig)
def percent(ax,label):
 ax.set_xlim(0,100);ax.set_xticks([0,25,50,75,100]);ax.grid(axis='x',color='#e3e8f0');ax.set_axisbelow(True);ax.tick_params(length=0,pad=8);ax.set_xlabel(label)
def annotate(ax,vals,y,offset=1.2,size=8):
 for v,p in zip(vals,y):ax.text(min(v+offset,98.4),p,f'{v:g}',va='center',fontsize=size,color='#192638')
suites=['spatial','object','goal','long'];r=read('openvla-oft-libero.csv')
fig,axs=plt.subplots(1,2,figsize=(12,6.5),layout='constrained')
for ax,group,configs,title in [(axs[0],'single_filtered',[('OpenVLA','OpenVLA',GRAY),('OpenVLA + PD&AC','Discrete PD+AC',TEAL),('OpenVLA-OFT','OFT / L1',BLUE),('OpenVLA + PD&AC + Diffusion','Continuous diffusion',PURPLE)],'Single view · Filtered data'),(axs[1],'multi_filtered',[('pi0 + FAST','pi0 + FAST',GRAY),('pi0','pi0',TEAL),('OpenVLA-OFT','OFT / L1',BLUE)],'Extra views/state · Filtered data')]:
 percent(ax,'Task success (%)');y=np.arange(4);n=len(configs);h=.72/n
 for i,(model,label,color) in enumerate(configs):
  row=next(x for x in r if x['protocol_group']==group and x['model']==model)
  vals=[float(row[s+'_sr_percent']) for s in suites];pos=y+(i-(n-1)/2)*h
  ax.barh(pos,vals,height=h*.85,color=color,label=label);annotate(ax,vals,pos,size=8)
 ax.set_yticks(y,[s.title() for s in suites]);ax.invert_yaxis();ax.set_title(title,loc='left',fontweight='bold',pad=18)
 ax.legend(loc='upper left',bbox_to_anchor=(0,-.16),ncol=2,frameon=False,fontsize=9)
fig.suptitle('OpenVLA-OFT v2 · Table I | Different input protocols shown separately',fontsize=11,color='#64748b')
save(fig,'openvla-oft-libero.svg')

r=read('openvla-oft-efficiency.csv');fig,axs=plt.subplots(2,2,figsize=(12,9),layout='constrained')
for env,pair in zip(['LIBERO','ALOHA'],axs):
 rows=[x for x in r if x['environment']==env];y=np.arange(len(rows));labels=[x['model'] for x in rows]
 colors=[BLUE if x['model'] in ['OFT L1','OFT + extra inputs','OpenVLA-OFT+'] else TEAL if x['model']=='PD + AC' else GRAY for x in rows]
 for ax,field,title in [(pair[0],'reported_action_throughput_hz','Action throughput (Hz)'),(pair[1],'reported_chunk_latency_seconds','Chunk latency (ms) · log scale')]:
  vals=[float(x[field])*(1000 if 'latency' in field else 1) for x in rows]
  ax.barh(y,vals,height=.6,color=colors);ax.set_yticks(y,labels);ax.invert_yaxis();ax.grid(axis='x',color='#e3e8f0');ax.set_axisbelow(True);ax.tick_params(length=0,pad=8)
  if 'latency' in field:
   ax.set_xscale('log');ax.set_xlim(30,4000);ax.set_xticks([50,100,300,1000,3000],['50','100','300','1000','3000'])
   for v,p in zip(vals,y):ax.text(v*1.07,p,f'{v:g}',va='center',fontsize=8)
  else:
   ax.set_xlim(0,max(vals)*1.18)
   for v,p in zip(vals,y):ax.text(v+max(vals)*.018,p,f'{v:g}',va='center',fontsize=8)
  ax.set_xlabel(title);ax.set_title(env+' · '+('Table II' if env=='LIBERO' else 'Table III'),loc='left',fontweight='bold',pad=12)
fig.suptitle('A100 · Mean over 100 queries | Action generation is distinct from robot control',fontsize=11,color='#64748b')
save(fig,'openvla-oft-efficiency.svg')

r=read('openvla-oft-aloha-scores.csv');models=['ACT','Diffusion Policy','RDT-1B','pi0','OpenVLA-OFT+'];tasks=list(dict.fromkeys(x['task'] for x in r));fig,axs=plt.subplots(2,2,figsize=(12,6.8),layout='constrained')
for ax,task in zip(axs.flat,tasks):
 vals=[float(next(x['reported_mean_score_out_of_100'] for x in r if x['task']==task and x['model']==m)) for m in models];y=np.arange(5)
 percent(ax,'Mean task score / 100 (not binary success rate)');ax.barh(y,vals,height=.57,color=[GRAY,GRAY,GRAY,TEAL,BLUE]);annotate(ax,vals,y,size=9)
 ax.set_yticks(y,models);ax.invert_yaxis();n=next(x['evaluation_trials'] for x in r if x['task']==task);ax.set_title(task+f' · {n} trials',loc='left',fontweight='bold',pad=12)
fig.suptitle('OpenVLA-OFT v2 · Tables X–XIII | Staged scoring includes partial credit and penalties',fontsize=11,color='#64748b')
save(fig,'openvla-oft-aloha.svg')

fig,axs=plt.subplots(1,2,figsize=(12,4.8),layout='constrained');y=np.arange(2)
for i,(m,label,color) in enumerate([('OpenVLA-OFT (no FiLM)','Without FiLM',GRAY),('OpenVLA-OFT+','With FiLM',BLUE)]):
 vals=[float(next(x['reported_mean_score_out_of_100'] for x in r if x['task']==t and x['model']==m)) for t in tasks[2:]];pos=y+(-.15 if i==0 else .15)
 axs[0].barh(pos,vals,height=.26,color=color,label=label);annotate(axs[0],vals,pos,size=9)
percent(axs[0],'ALOHA mean task score / 100');axs[0].set_yticks(y,['Scoop','Put in pot']);axs[0].invert_yaxis();axs[0].set_title('FiLM · ALOHA scoring',loc='left',fontweight='bold',pad=15);axs[0].legend(loc='upper left',bbox_to_anchor=(0,-.19),ncol=2,frameon=False)
r=read('openvla-oft-ablations.csv');rows=[x for x in r if x['experiment']=='robot_pretraining'];vals=[float(x['reported_average_sr_percent']) for x in rows]
percent(axs[1],'LIBERO average task success (%)');axs[1].barh(y,vals,height=.48,color=[BLUE,GRAY]);annotate(axs[1],vals,y,size=9);axs[1].set_yticks(y,['OpenVLA init','Prismatic VLM init']);axs[1].invert_yaxis();axs[1].set_title('Robot pretraining · LIBERO',loc='left',fontweight='bold',pad=15)
fig.suptitle('Tables XII–XIII and XV | Different metrics; Prismatic init retains VLM pretraining',fontsize=11,color='#64748b')
save(fig,'openvla-oft-ablations.svg')

class SVG:
 def __init__(self,w,h,title,desc):
  self.items=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title desc"><title id="title">{escape(title)}</title><desc id="desc">{escape(desc)}</desc><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#7086a8"/></marker></defs><rect width="{w}" height="{h}" fill="white"/><g font-family="Inter,Noto Sans SC,system-ui,sans-serif">']
 def text(self,x,y,s,size=16,color='#192638',bold=False):self.items.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}"'+(' font-weight="600"' if bold else '')+'>'+escape(s)+'</text>')
 def box(self,x,y,w,h,lines,kind='normal'):
  fill,stroke={'normal':('#f7f9fc','#dce4ef'),'blue':('#edf3ff','#a9c2f5'),'teal':('#eff8f7','#99cdcb')}[kind]
  self.items.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{fill}" stroke="{stroke}"/>')
  for i,line in enumerate(lines):self.text(x+16,y+29+i*25,line,16 if i==0 else 14,'#245ce2' if kind=='blue' and i==0 else '#137c79' if kind=='teal' and i==0 else '#52637d',i==0)
 def arrow(self,d,dashed=False):self.items.append(f'<path d="{d}" fill="none" stroke="#7086a8" stroke-width="2"'+(' stroke-dasharray="6 5"' if dashed else '')+' marker-end="url(#arrow)"/>')
 def save(self,name):(R/'dist/assets'/name).write_text(''.join(self.items)+'</g></svg>')
d=SVG(1140,872,'OpenVLA-OFT 架构','观测与KD个空动作槽进入双向Llama2，连续MLP输出整个块；OFT加FiLM只在增强版本使用。')
d.text(34,38,'OpenVLA-OFT / 预训练骨干，新的连续动作路径',24,bold=True)
d.text(34,66,'理解重绘 · 不输入未来真实动作；一次前向计算所有动作位置。',14,'#64748b')
d.box(34,112,278,116,['多视角 RGB','LIBERO：第三视角 + 腕部','ALOHA：顶部 + 左右腕部','每张图像 224 × 224'],kind='blue')
d.box(360,112,348,116,['共享 DINOv2 + SigLIP','对应 patch 按隐藏维拼接','3 层 GELU MLP 视觉投影','每视角 256 个视觉 tokens'],kind='blue')
d.box(758,112,348,116,['多个视角，沿序列维拼接','LIBERO 完整配置：512 tokens','ALOHA：768 tokens','共享骨干与视觉投影器'],kind='blue')
d.arrow('M312 170H355');d.arrow('M708 170H753')
d.box(34,272,278,91,['任务语言','Llama-2 词嵌入','指令作为输入条件'])
d.box(360,272,348,91,['OFT+ 专属：视觉 FiLM','语言均值 → 每层 γ、β','在两个视觉骨干中调制隐藏通道'],kind='teal')
d.arrow('M312 318H355',True);d.arrow('M534 270V233',True)
d.box(758,272,348,91,['当前机器人状态','2 层 GELU MLP → 一个 token','没有额外的未来状态输入'])
d.text(34,411,'并行输出区域：K × D 个空动作槽，只靠位置编码区分。',16,'#245ce2',True)
d.box(34,444,278,118,['空动作槽 Eempty','LIBERO：8 × 7 = 56 个','ALOHA：25 × 14 = 350 个','空嵌入，不是真实动作'],kind='blue')
d.box(360,444,348,118,['Llama-2 Transformer + LoRA','图像 + 语言 + 状态 + 空动作槽','由因果注意力改为双向注意力','一次得到所有动作位置表征'],kind='blue')
d.box(758,444,348,118,['连续动作头','4 层 ReLU MLP','动作位置的隐藏状态 → K × D','不经词表 softmax 与分箱'],kind='blue')
d.arrow('M312 504H355');d.arrow('M708 504H753')
d.arrow('M932 230V247H734V421H670V439');d.arrow('M932 365V395H650V439');d.arrow('M173 365V387H332V471H355')
d.box(360,616,348,92,['训练：归一化动作块监督','L1(预测，示范目标)','更新 LoRA 与新增模块'])
d.box(758,616,348,92,['推理：反归一化并执行整块','LIBERO 执行 8 步；ALOHA 25 步','块间重新观察，再查询策略'])
d.arrow('M932 565V611');d.arrow('M758 536H734V662H714',True)
d.arrow('M932 710V779H18V170H29')
d.text(360,763,'执行循环：不是原版 ACT 的每步时序集成。',15,'#64748b')
d.text(34,811,'训练目标中的未来示范不会成为模型输入；FiLM 是可选增强，不属于 LIBERO 主配置。',14,'#64748b')
d.text(34,840,'来源：论文 v2 §IV-B/C、附录 A-A/B/C、Tables IV–V；省略起止 token 与边界处理细节。',13,'#64748b')
d.save('openvla-oft-architecture.svg')

d=SVG(1120,724,'自回归与并行解码','原版训练时teacher forcing加因果mask，推理逐个反馈；OFT的动作槽为空且双向可见，一次输出六个教学动作位置。')
d.text(34,38,'动作输出 / 生成依赖，与动作的时间序列分开',23,bold=True)
d.text(34,66,'教学例子 K=2、D=3，共 6 个动作标量位置；不是论文实验规格。',14,'#64748b')
d.text(34,110,'01 / 自回归方案：从原版机制扩展到动作块',16,'#52637d',True)
d.box(34,132,1052,87,['训练输入：观测／语言 + 右移的真实动作 token（teacher forcing）','因果 mask 防止看到目标之后的动作；损失是离散 token 的交叉熵。'])
for i in range(6):
 x=34+i*178;d.box(x,253,158,69,[f'位置 {i+1}',f'预测 token {i+1}'])
 if i<5:d.arrow(f'M{x+159} 285H{x+173}')
d.text(34,354,'推理：预测 → 反馈为下一位置输入 → 再预测；存在 6 次顺序依赖。',15,'#64748b')
d.text(34,405,'02 / OFT：双向注意力 + 空动作槽 + 连续输出',16,'#245ce2',True)
for i in range(6):
 x=34+i*178;d.box(x,426,158,69,[f'空槽 {i+1}',f'位置编码 {i+1}'],kind='blue')
d.box(34,526,1052,74,['共享双向 Transformer：各空槽可利用整段当前输入和其他槽的中间表征','空槽里没有未来真实动作，也没有此前预测出的动作作为递归输入。'],kind='blue')
for i in range(6):d.arrow(f'M{113+i*178} 497V521')
d.arrow('M560 602V631')
d.text(228,661,'一次前向 → 连续动作块 [aₜ, aₜ₊₁] ∈ ℝ²ˣ³',21,'#245ce2',True)
d.text(34,704,'“并行”指计算方式；块内仍有明确时间顺序，并非把所有目标同时送给控制器。',14,'#64748b')
d.save('openvla-oft-decoding.svg')
print('Rendered four OpenVLA-OFT data charts and two explanatory diagrams.')
