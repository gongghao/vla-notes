"""Draw Astra report figures from the fixed September 2026 public snapshot.

Values describe selected runs. No policy reproduction or inferred confidence bars.
"""
from pathlib import Path
import csv
from xml.sax.saxutils import escape
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BLUE, TEAL, GRAY, ORANGE = '#245ce2', '#137c79', '#9cabc4', '#ad7130'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'svg.fonttype': 'none', 'font.size': 10,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.spines.left': False, 'axes.spines.bottom': False})

def read(name):
    with (ROOT / 'dist/data' / name).open() as f:
        return list(csv.DictReader(f))

def save(fig, name):
    fig.savefig(ROOT / 'dist/assets' / name, bbox_inches='tight', facecolor='white')
    plt.close(fig)

def style(ax, xlabel, limit=100):
    ax.set_xlim(0, limit)
    ax.grid(axis='x', color='#e3e8f0')
    ax.set_axisbelow(True)
    ax.tick_params(length=0, pad=8)
    ax.set_xlabel(xlabel)

models = read('astra-robodojo-overall.csv')
order = ['mix', 'gpt', 'Pi-05']
rows = [next(r for r in models if r['model_key'] == key) for key in order]
fig, axs = plt.subplots(1, 2, figsize=(12, 4.7), layout='constrained')
for ax, field, title in [(axs[0], 'success_rate_percent', 'Native success (%)'),
                          (axs[1], 'mean_score_100', 'Partial-credit Score / 100')]:
    values = [float(r[field]) for r in rows]
    bars = ax.barh(np.arange(3), values, height=.49, color=[BLUE, TEAL, GRAY])
    bars[2].set_hatch('///')
    bars[2].set_edgecolor('#64748b')
    labels = ['Hybrid', 'Astra Direct', 'pi0.5 / official']
    if field == 'mean_score_100':
        labels = ['Hybrid · n=50', 'Astra Direct · n=48', 'pi0.5 / official']
    for i, v in enumerate(values):
        note = (' · ' + rows[i]['successes'] + '/50') if i < 2 and field == 'success_rate_percent' else ''
        ax.text(v + 1.5, i, f'{v:.2f}' + note, va='center', fontsize=9)
    ax.set_yticks(np.arange(3), labels)
    ax.invert_yaxis()
    style(ax, title)
    ax.set_title(title, loc='left', fontweight='bold', pad=18)
fig.suptitle('RoboDojo · Selected ten tasks | Official aggregates are reweighted, not paired reruns',
             fontsize=11, color='#64748b')
save(fig, 'astra-robodojo-overall.svg')

task_names = {'organize_table': 'Organize table', 'classify_objects_by_language': 'Classify by language',
              'imitate_sorting_sequence': 'Imitate sorting order', 'arrange_largest_number': 'Largest number',
              'pack_objects_into_box': 'Pack into box', 'classify_objects': 'Classify objects',
              'build_tower': 'Build tower', 'make_kong': 'Mahjong kong',
              'fold_clothes': 'Fold clothes', 'put_bottles_into_dustbin': 'Bottles into bin'}
data = read('astra-robodojo-tasks.csv')
for field, name, xlabel in [('success_rate_percent', 'astra-robodojo-task-success.svg', 'Native success (%) · 5 runs per task'),
                             ('mean_score_100', 'astra-robodojo-task-score.svg', 'Partial-credit Score / 100')]:
    fig, ax = plt.subplots(figsize=(11.6, 7.8), layout='constrained')
    tasks = list(task_names)
    y = np.arange(10)
    for key, offset, color, label in [('mix', -.17, BLUE, 'Hybrid'), ('gpt', .17, TEAL, 'Astra Direct')]:
        rows = [next(r for r in data if r['task'] == task and r['model_key'] == key) for task in tasks]
        values = [float(r[field]) for r in rows]
        ax.barh(y + offset, values, height=.27, color=color, label=label)
        for p, v in zip(y + offset, values):
            ax.text(v + .9, p, f'{v:g}', va='center', fontsize=9)
    labels = [task_names[t] for t in tasks]
    if field == 'mean_score_100':
        labels = [label + (' · Direct n=4' if tasks[i] in ['classify_objects_by_language', 'pack_objects_into_box'] else '')
                  for i, label in enumerate(labels)]
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    style(ax, xlabel, 110)
    ax.set_xticks([0, 20, 40, 60, 80, 100])
    ax.set_title('RoboDojo · Task-level selected results', loc='left', fontweight='bold', pad=18)
    ax.legend(loc='upper left', bbox_to_anchor=(0, -.08), frameon=False, ncol=2)
    save(fig, name)

data = read('astra-robolab-overall.csv')
order = ['pure_astra', 'astra_pi05', 'pi05_only', 'cosmos_nano_policy', 'dreamzero']
rows = [next(r for r in data if r['method'] == key) for key in order]
fig, ax = plt.subplots(figsize=(11.4, 5.4), layout='constrained')
values = [float(r['success_rate_percent']) for r in rows]
bars = ax.barh(np.arange(5), values, height=.5, color=[TEAL, BLUE, GRAY, GRAY, GRAY])
for bar in list(bars)[2:]:
    bar.set_hatch('///')
    bar.set_edgecolor('#64748b')
for i, (v, r) in enumerate(zip(values, rows)):
    ax.text(v + 1.4, i, f'{v:g}% · {r["successes"]}/{r["episodes"]}', va='center')
ax.set_yticks(np.arange(5), ['Astra Direct', 'Hybrid', 'pi0.5 / historical', 'Cosmos3-Nano / historical', 'DreamZero / historical'])
ax.invert_yaxis()
style(ax, 'Final-slot success rate (%)', 119)
ax.set_xticks([0, 20, 40, 60, 80, 100])
ax.set_title('RoboLab · Ten tasks × five final slots per method', loc='left', fontweight='bold', pad=18)
fig.suptitle('Includes retained runs / retries | Initial states not strictly paired; decision budgets differ',
             fontsize=11, color='#64748b')
save(fig, 'astra-robolab.svg')

rows = read('astra-usage.csv')
fig, axs = plt.subplots(1, 2, figsize=(12, 4.8), layout='constrained')
parts = [('cached_input_tokens', 'Cached input', GRAY),
         ('uncached_input_tokens', 'Uncached input', BLUE), ('output_tokens', 'Output', TEAL)]
for ax, selected, title, limit in [(axs[0], parts, 'All tokens · includes cached input', 1320),
                                   (axs[1], parts[1:], 'New input and output only', 31)]:
    left = np.zeros(2)
    for field, label, color in selected:
        values = np.array([float(r[field]) / 1e6 for r in rows])
        ax.barh(np.arange(2), values, left=left, height=.42, color=color, label=label)
        left += values
    for i, v in enumerate(left):
        ax.text(v + limit * .015, i, f'{v:.2f} M', va='center', fontsize=9)
    ax.set_yticks([0, 1], ['Hybrid', 'Astra Direct'])
    ax.invert_yaxis()
    style(ax, 'Million tokens · selected RoboDojo runs', limit)
    ax.set_title(title, loc='left', fontweight='bold', pad=18)
    ax.legend(loc='upper left', bbox_to_anchor=(0, -.17), frameon=False, ncol=1 if len(selected) == 3 else 2, fontsize=9)
fig.suptitle('No all-retry total, pricing conversion, or measured wall-clock latency', fontsize=11, color='#64748b')
save(fig, 'astra-usage.svg')

class SVG:
    def __init__(self, w, h, title, desc):
        self.items = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" '
                      f'aria-labelledby="title desc"><title id="title">{escape(title)}</title>'
                      f'<desc id="desc">{escape(desc)}</desc><defs><marker id="arrow" markerWidth="8" '
                      'markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" '
                      'fill="#7086a8"/></marker></defs>'
                      f'<rect width="{w}" height="{h}" fill="white"/>'
                      '<g font-family="Inter,Noto Sans SC,system-ui,sans-serif">']

    def text(self, x, y, text, size=16, color='#192638', bold=False):
        self.items.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}"'
                          + (' font-weight="600"' if bold else '') + '>' + escape(text) + '</text>')

    def box(self, x, y, w, h, lines, kind='normal'):
        fill, stroke = {'normal': ('#f7f9fc', '#dce4ef'), 'blue': ('#edf3ff', '#a9c2f5'),
                        'teal': ('#eff8f7', '#99cdcb')}[kind]
        self.items.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{fill}" stroke="{stroke}"/>')
        for i, line in enumerate(lines):
            self.text(x + 16, y + 29 + i * 25, line, 16 if i == 0 else 14,
                      BLUE if kind == 'blue' and i == 0 else TEAL if kind == 'teal' and i == 0 else '#52637d', i == 0)

    def arrow(self, path):
        self.items.append(f'<path d="{path}" fill="none" stroke="#7086a8" stroke-width="2" marker-end="url(#arrow)"/>')

    def save(self, name):
        (ROOT / 'dist/assets' / name).write_text(''.join(self.items) + '</g></svg>')

d = SVG(1140, 1080, 'Astra Hybrid 与 Direct 闭环', 'RoboDojo 候选审核、二选一执行、新观察与 Direct EEF 控制。')
d.text(34, 38, 'Astra 作为具身策略 / 相同 agent，不同动作先验', 24, bold=True)
d.text(34, 66, '理解重绘 · 规格仅对应 RoboDojo 双臂 ARX X5；不混用 RoboLab 单臂接口。', 14, '#64748b')
d.text(34, 112, '01 / Hybrid：运动候选 + Outcome / Intent 审核', 18, BLUE, True)
d.box(34, 139, 300, 116, ['当前条件', '三路 RGB + 14 维本体', '原始任务指令', '历史、持久笔记与工具'])
d.box(418, 139, 300, 116, ['任务微调 π₀.₅', '输出 50 × 14 关节候选', '双臂机器人 FK 轨迹', '不含物体未来状态'], 'blue')
d.box(802, 139, 304, 116, ['GPT 6 Astra / xhigh', '上一段：实际执行结果', '下一段：推断子目标意图', '选择沿用或局部接管'], 'blue')
d.arrow('M334 197H413'); d.arrow('M718 197H797')
d.box(418, 316, 300, 116, ['分支 A：沿用学生', '执行新候选的前 1–15 步', '保留关节空间轨迹', '剩余后缀丢弃'], 'blue')
d.box(802, 316, 304, 116, ['分支 B：EEF 修正', '执行 1–5 步局部修正', '目标 → 有界局部 IK', '不是两组动作相加'], 'teal')
d.arrow('M954 257V286H568V311'); d.arrow('M954 286V311')
d.text(34, 350, '每次只走一条分支', 16, '#64748b', True)
d.text(34, 380, '不确定本身不触发接管', 14, '#64748b')
d.box(418, 493, 688, 91, ['低层执行 → 新图像、实测状态与原生结局', '命令不证明到达／抓住；段内错误要等下一次观察确认', '继续未完成的任务，或读取原生成功／失败后终止'])
d.arrow('M568 434V488'); d.arrow('M954 434V488')
d.arrow('M418 539H18V197H29')
d.text(34, 647, '02 / Direct：不运行 π₀.₅，每段动作都由 Astra 提出', 18, TEAL, True)
d.box(34, 674, 300, 116, ['相同观测与原始任务', '机器人／EEF 接口说明', '执行历史与持久笔记', '不是无上下文的单图控制'])
d.box(418, 674, 300, 116, ['GPT 6 Astra / xhigh', '自行规划双臂 EEF 目标', '位置、姿态与夹爪命令', '保留视觉检查与计算工具'], 'teal')
d.box(802, 674, 304, 116, ['有界局部 IK → 执行', '1–5 个控制步', '没有学生提议或关节直出', '执行完再反馈'], 'teal')
d.arrow('M334 732H413'); d.arrow('M718 732H797')
d.box(418, 850, 688, 91, ['同样读取新观察与原生结局', '原生终止不等于成功；局部目标不等于已执行到位', '机器人状态与任务进度随真实执行更新'])
d.arrow('M954 792V845'); d.arrow('M418 896H18V732H29')
d.text(34, 995, '两种架构不更新 GPT 参数；学生先验、候选接口与执行段长仍是共同变化的因素。', 14, '#64748b')
d.text(34, 1034, '来源：报告 §2.1、完整 Skill、Outcome / Intent gate 与双臂 EEF 合同；公开快照 6ead090。', 13, '#64748b')
d.save('astra-architecture.svg')

d = SVG(1140, 652, '模拟物理时间与墙钟等待', '图像工具、候选推理、Astra决策、执行、新观察循环；等待宽度为教学示意。')
d.text(34, 38, '时间口径 / 25 Hz 控制，不等于 25 Hz 语义决策', 24, bold=True)
d.text(34, 66, '下方框宽为机制示意，不是测得的响应时间；Hybrid 示例只画沿用学生的分支。', 14, '#64748b')
for x, width, lines, kind in [
        (34, 186, ['观察与传输', '三路图像／状态', '工具与文件处理'], 'normal'),
        (254, 186, ['候选推理', 'π₀.₅ → 50 步', '生成不等于执行'], 'blue'),
        (474, 186, ['Astra 决策', 'Outcome / Intent', '审核并选分支'], 'teal'),
        (694, 186, ['执行前缀 k 步', 'k=1…15', '模拟时间 k×0.04 s'], 'blue'),
        (914, 192, ['下一次观察', '实测状态与结局', '重建当前判断'], 'normal')]:
    d.box(x, 127, width, 116, lines, kind)
for x in [220, 440, 660, 880]: d.arrow(f'M{x} 185H{x+29}')
d.box(34, 294, 1072, 92, ['报告的模拟物理时间，只累计执行区域', 'Hybrid：42,750 × 0.04 / 50 = 34.20 s；Direct：38,221 × 0.04 / 50 ≈ 30.58 s',
                         '不包括模型响应、工具传输、候选推理与其他墙钟等待'])
d.box(34, 427, 1072, 92, ['暂停式仿真，降低了慢推理的代价', '机器人可在 agent 思考时停下；现实中的物体、人和接触过程可能持续变化',
                         '更短的物理轨迹也可能来自失败或未终止运行，不能直接解释为更高端到端效率'], 'teal')
d.text(34, 573, '缺少墙钟与动态场景证据时，成功率和 0.04 s 步长不足以推出实时部署能力。', 15, '#52637d')
d.text(34, 616, '来源：报告摘要、§2.1、§6.3 与 Table 3；等待时长未被补造。', 13, '#64748b')
d.save('astra-timing.svg')
