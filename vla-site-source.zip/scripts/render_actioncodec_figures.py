"""ActionCodec v2: published table figures and explanatory mechanism drawings.
No policy execution, digitized curves, or invented uncertainty estimates.
"""
from pathlib import Path
import csv
from xml.sax.saxutils import escape
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
BLUE,TEAL,GRAY,ORANGE='#245ce2','#137c79','#8d9cb3','#ad7130'
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
def read(name):
 with (ROOT/'dist/data'/('actioncodec-'+name+'.csv')).open() as f:return list(csv.DictReader(f))
def save(fig,name):
 fig.savefig(ROOT/'dist/assets'/('actioncodec-'+name+'.svg'),bbox_inches='tight',facecolor='white');plt.close(fig)
def axis(ax,xlabel,limit=100):
 ax.set_xlim(0,limit);ax.grid(axis='x',color='#e3e8f0');ax.set_axisbelow(True);ax.tick_params(length=0,pad=8);ax.set_xlabel(xlabel)
def bars(ax,labels,values,colors,title,limit=100,fmt='.1f'):
 y=np.arange(len(labels));ax.barh(y,values,color=colors,height=.55);ax.set_yticks(y,labels);ax.invert_yaxis();axis(ax,title,limit)
 for i,v in enumerate(values):ax.text(v+limit*.012,i,format(v,fmt),va='center',fontsize=9)
r=read('overlap');fig,axs=plt.subplots(1,3,figsize=(12.2,4),layout='constrained')
labels=[x['or_percent']+'% OR' for x in r];colors=[GRAY,TEAL,BLUE]
for ax,field,label,limit,fmt in [(axs[0],'success_at_500_steps_percent','Goal success at 500 steps (%)',40,'.1f'),(axs[1],'l1_reconstruction_error','L1 reconstruction error',.035,'.3f'),(axs[2],'marginal_token_usage_perplexity','Marginal token-usage PPL',2300,'.0f')]:
 bars(ax,labels,[float(x[field]) for x in r],colors,label,limit,fmt)
fig.suptitle('Table 5 | n=16, S=2048; 100% codebook utilization in every variant',fontsize=11,color='#64748b');save(fig,'overlap')
r=read('libero');r=[x for x in r if x['panel']=='c'];left=[x for x in r if x['method'] not in ['ActionCodec-PD','ActionCodec-KI','ActionCodec-BAR'] and x['method'] not in ['ActionCodec (256M)','ActionCodec (500M)']];right=[x for x in r if x['method'] in ['ActionCodec (2.2B)','ActionCodec-PD','ActionCodec-KI','ActionCodec-BAR']]
fig,axs=plt.subplots(1,2,figsize=(12.6,5.7),layout='constrained')
for ax,rows,title in [(axs[0],left,'Native AR | SmolVLM2-2.2B'),(axs[1],right,'AR reference vs. action-expert variants')]:
 bars(ax,[x['method'].replace(' (2.2B)',' AR') for x in rows],[float(x['reported_average_percent']) for x in rows],[BLUE if x['method']=='ActionCodec (2.2B)' else TEAL if x['method'].startswith('ActionCodec') else GRAY for x in rows],'LIBERO reported average success (%)',108)
 ax.set_title(title,loc='left',fontweight='bold',pad=18)
fig.suptitle('Table 1(c) | No policy VLA pre-training; tokenizer pre-training is separate',fontsize=11,color='#64748b');save(fig,'libero')
r=read('efficiency');labels=[x['method']+' / H='+x['horizon'] for x in r];fig,axs=plt.subplots(1,3,figsize=(12.8,6.4),layout='constrained')
colors=[BLUE if x['method']=='ActionCodec' else TEAL if x['method']=='FAST' else GRAY for x in r]
for ax,field,title,log in [(axs[0],'token_budget','Tokens / chunk (log scale)',True),(axs[1],'latency_seconds','Policy latency / chunk, s (log scale)',True),(axs[2],'throughput_actions_per_second','Reported actions / second',False)]:
 vals=[float(x[field]) for x in r];y=np.arange(len(r));ax.barh(y,vals,height=.53,color=colors);ax.set_yticks(y,labels if ax is axs[0] else []);ax.invert_yaxis();ax.set_xlabel(title);ax.grid(axis='x',color='#e3e8f0');ax.set_axisbelow(True);ax.tick_params(length=0)
 if log:ax.set_xscale('log');ax.set_xlim(.35 if field=='latency_seconds' else 2,100 if field=='latency_seconds' else 2500)
 else:ax.set_xlim(0,27)
 for i,v in enumerate(vals):ax.text(v*1.09 if log else v+.5,i,f'{v:.1f}',va='center',fontsize=9)
fig.suptitle('Table 2 | Different horizons retained; reported +/- values are not plotted as confidence bars',fontsize=11,color='#64748b');save(fig,'efficiency')
r=read('large-transfer');fig,axs=plt.subplots(1,3,figsize=(12.3,4.8),layout='constrained')
for ax,field,title in [(axs[0],'simpler_widowx_ft_percent','Simpler-WidowX / task FT'),(axs[1],'libero_ft_percent','LIBERO / task FT'),(axs[2],'droid_zs_percent','DROID / zero-shot')]:
 rows=[x for x in r if x[field]];bars(ax,[x['method'].replace(' Qwen3.5-2B','\nQwen3.5-2B') for x in rows],[float(x[field]) for x in rows],[BLUE if x['method'].startswith('ActionCodec') else GRAY for x in rows],'Reported benchmark success (%)',110);ax.set_title(title,loc='left',fontweight='bold',pad=18)
fig.suptitle('Table 10 | ActionCodec VLA pre-training: 15K hours / 14 embodiments / KI',fontsize=11,color='#64748b');save(fig,'large-transfer')
r=read('ablation');fig,axs=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
for ax,rows,title in [(axs[0],r[:4],'SmolVLM2-2.2B | Conditional design comparisons'),(axs[1],r[3:],'Full design | Backbone replacement')]:
 labels=[f"ID {x['id']} | CT={x['co_training']} SP={x['soft_prompt']} RVQ={x['rvq_post_training']}" if ax is axs[0] else x['vlm'] for x in rows]
 bars(ax,labels,[float(x['libero_average_percent']) for x in rows],[BLUE if x['id']=='3' else GRAY for x in rows],'LIBERO average success (%)',107);ax.set_title(title,loc='left',fontweight='bold',pad=18,fontsize=10)
fig.suptitle('Table 4 | Not a full factorial experiment; no reported uncertainty added',fontsize=11,color='#64748b');save(fig,'ablation')
class Diagram:
 def __init__(self,h,title,desc):
  self.h=h;self.p=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 {h}" role="img"><title>{escape(title)}</title><desc>{escape(desc)}</desc><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#8090aa"/></marker></defs><rect width="1200" height="{h}" fill="#fff"/><style>text{{font-family:system-ui,"Noto Sans CJK SC",sans-serif;fill:#24354f}}.small{{font-size:16px;fill:#64748b}}.title{{font-size:24px;font-weight:700}}.body{{font-size:19px}}.boxhead{{font-size:20px;font-weight:650}}.arrow{{fill:none;stroke:#8090aa;stroke-width:2.5;marker-end:url(#arrow)}}</style>']
 def text(self,x,y,text,cls='body',anchor='start'):self.p.append(f'<text x="{x}" y="{y}" class="{cls}" text-anchor="{anchor}">{escape(text)}</text>')
 def box(self,x,y,w,h,title,lines,fill='#f2f6ff'):
  self.p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="{fill}" stroke="#d7e1ee"/>');self.text(x+18,y+31,title,'boxhead')
  for i,line in enumerate(lines):self.text(x+18,y+61+i*27,line,'small')
 def arrow(self,x1,y1,x2,y2):self.p.append(f'<path d="M{x1} {y1} L{x2} {y2}" class="arrow"/>')
 def save(self,name):(ROOT/'dist/assets'/('actioncodec-'+name+'.svg')).write_text(''.join(self.p)+'</svg>')
d=Diagram(740,'ActionCodec: tokenizer and VLA paths','动作tokenizer训练路径与原生自回归策略训练、推理路径分开。')
d.text(36,43,'ActionCodec · 学习动作标签，再由 VLM 预测标签','title');d.text(36,76,'理解重绘 · v2 §2/§4；Appendices B/C · n=16，S=2048','small')
d.text(36,122,'① Tokenizer 训练：读取真实动作，学习可重建的离散表示','boxhead')
d.box(36,151,236,120,'动作块 A',['T × D；一秒窗口','动作 + 物理时间戳'])
d.box(314,151,236,120,'Perceiver encoder',['16 个 latent query','cross-attention → Z'])
d.box(592,151,236,120,'VQ / 2048 码本',['最近邻 → 16 个索引 C','重建 / 码本 / commitment'])
d.box(870,151,294,120,'Perceiver decoder',['查码向量 → 轨迹 Â','用 A 与 Â 计算重建损失'])
for x1,x2 in [(272,314),(550,592),(828,870)]:d.arrow(x1,211,x2,211)
d.box(36,294,1128,90,'平台条件与对比监督',['embodiment ID soft prompt；Fourier 时间编码；TCL 邻近动作 / CLIP 风格动作-语言对齐'],'#edf7f5')
d.text(36,432,'② 策略训练：真实动作编码出的 C 成为 VLM 的监督标签','boxhead')
d.box(36,457,325,100,'当前观察 + 语言 + 状态',['不输入未来真实轨迹'])
d.box(407,457,360,100,'预训练 VLM → 动作 token',['扩展动作词表；全参数 AR 微调'])
d.box(813,457,351,100,'标签 C / next-token loss',['来自已训练动作 tokenizer'])
d.arrow(361,507,407,507);d.arrow(813,507,767,507)
d.text(36,606,'③ 原生 AR 推理：观察 → VLM 预测 Ĉ → decoder → 动作块','boxhead')
d.text(36,640,'encoder 用于制作训练标签；推理读取预测码，不依赖未来真实动作。','body')
d.text(36,676,'token 数 n、动作步数 T、关节维度 D 是不同轴；PD / KI / BAR 另见策略变体。','small')
d.save('architecture')
d=Diagram(738,'ActionCodec RVQ post-training and deployment','单层VQ稳定标签，冻结主encoder和codebook后做RVQ；普通VQ和BAR部署区别。')
d.text(36,43,'ActionCodec · 主标签稳定，残差用于精度','title');d.text(36,76,'理解重绘 · v2 §4 / Appendices C/D；RVQ n=16，深度 L=3','small')
d.box(36,116,343,153,'阶段 1 · 单层 VQ',['学习 encoder / 主码本 / decoder','TCL + CLIP 风格监督','得到稳定主层 C₁：16 token'])
d.box(430,116,734,153,'阶段 2 · RVQ 后训练',['继承并冻结 encoder 与主码本 → C₁ 保持不变','增加残差码本，使用重建损失与 RVQ 目标后训练','三层码 C₁ / C₂ / C₃，逐层表达剩余误差'],'#edf7f5');d.arrow(379,192,430,192)
d.arrow(797,269,797,311)
d.box(36,322,540,167,'部署 A · 普通单层 VQ 路径',['复制后训练 RVQ decoder 权重回 VQ','策略仍预测原主层 16 token → 轨迹','除 BAR 外的评测采用这一路径','冻结确保主编码不变；仍有后训练成本'])
d.box(624,322,540,167,'部署 B · BAR 完整 RVQ',['增加约 300M 参数 action expert','C₁ 的16位置并行 → C₂ → C₃','层内互相可见；层间因果预测','此路径不能沿用“只输出16个码”的预算'],'#edf7f5')
d.arrow(797,311,306,311);d.arrow(306,311,306,322);d.arrow(797,311,894,311);d.arrow(894,311,894,322)
d.box(36,528,1128,127,'跨平台接口 · Soft prompt',['embodiment ID：每平台一个学习向量；共享网络表达通用结构','encoder K/V 与 decoder query：以 Hz 和动作时长计算时间，再作 Fourier 编码','这不是自然语言提示，也不是无需运动学适配的通用控制器'])
d.text(36,699,'单层 VQ 的成功率 95.2 → 95.5（Table 4）；BAR 的 97.4 是另一策略配置。','small');d.save('rvq')
print('Rendered five data charts and two mechanism diagrams from fixed v2 evidence.')
