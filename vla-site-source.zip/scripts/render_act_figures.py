"""Render ACT v1 reported data and original explanatory SVG diagrams."""
from pathlib import Path
from xml.sax.saxutils import escape
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
def read(name):
    with (ROOT/'dist/data'/name).open() as f:return list(csv.DictReader(f))
def axes_style(ax):
    ax.set_xlim(0,100);ax.set_xticks([0,25,50,75,100]);ax.grid(axis='x',color='#e3e8f0');ax.set_axisbelow(True);ax.tick_params(length=0,pad=8);ax.set_xlabel('Success (%)')
def labels(ax,values,y):
    for v,pos in zip(values,y):ax.text(min(v+1.2,98),pos,f'{v:g}',va='center',fontsize=10,color='#192638')
def finish(fig,name):
    fig.savefig(ROOT/'dist/assets'/name,bbox_inches='tight',facecolor='white');plt.close(fig)
r=read('act-real-results.csv');tasks=list(dict.fromkeys(x['task'] for x in r));y=np.arange(len(tasks))
fig,ax=plt.subplots(figsize=(11,5),layout='constrained');axes_style(ax)
for model,color,offset in [('ACT','#245ce2',-.16),('BeT','#9cabc4',.16)]:
    values=[float(next(x['success_percent'] for x in r if x['task']==t and x['model']==model)) for t in tasks]
    ax.barh(y+offset,values,height=.28,color=color,label=model);labels(ax,values,y+offset)
ax.set_yticks(y,tasks);ax.invert_yaxis();ax.legend(loc='center left',bbox_to_anchor=(1.01,.5),frameon=False)
ax.set_title('Real tasks · Final subtask success',loc='left',fontweight='bold',pad=15)
fig.suptitle('ACT v1 · Tables I–II | Human demonstrations | 1 seed × 25 evaluations per task',fontsize=11,color='#64748b')
finish(fig,'act-real-results.svg')
r=read('act-sim-results.csv');models=['BC-ConvMLP','BeT','RT-1','VINN','ACT'];fig,axs=plt.subplots(1,2,figsize=(12,4.6),layout='constrained');y=np.arange(len(models))
for ax,task in zip(axs,['Cube Transfer','Bimanual Insertion']):
    axes_style(ax)
    for dataset,color,offset in [('scripted','#245ce2',-.16),('human','#137c79',.16)]:
        values=[float(next(x['success_percent'] for x in r if x['task']==task and x['model']==m and x['training_data']==dataset)) for m in models]
        ax.barh(y+offset,values,height=.28,color=color,label=dataset.capitalize());labels(ax,values,y+offset)
    ax.set_yticks(y,models);ax.invert_yaxis();ax.set_title(task,loc='left',fontweight='bold',pad=15)
axs[1].legend(loc='center left',bbox_to_anchor=(1.01,.5),frameon=False)
fig.suptitle('ACT v1 · Table I | Final subtask | Mean over 3 seeds, 50 evaluations per seed',fontsize=11,color='#64748b')
finish(fig,'act-sim-results.svg')
r=read('act-ablations.csv');fig,axs=plt.subplots(1,2,figsize=(12,3.8),layout='constrained')
for ax,exp,title in zip(axs,['chunk_size','cvae'],['Chunking · TE disabled\n4 simulation settings','CVAE · Human demonstrations\n2 simulation tasks']):
    items=[x for x in r if x['experiment']==exp];values=[float(x['success_percent']) for x in items];y=np.arange(len(items));axes_style(ax)
    ax.barh(y,values,color=['#9cabc4','#245ce2'],height=.48);labels(ax,values,y)
    ax.set_yticks(y,[x['condition'] for x in items]);ax.invert_yaxis();ax.set_title(title,loc='left',fontweight='bold',pad=15)
fig.suptitle('ACT v1 · VI-A/B | Explicitly reported points only; panels use different aggregates',fontsize=11,color='#64748b')
finish(fig,'act-ablations.svg')

class SVG:
    def __init__(self,w,h,title,desc):
        self.items=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title desc"><title id="title">{escape(title)}</title><desc id="desc">{escape(desc)}</desc><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#7086a8"/></marker></defs><rect width="{w}" height="{h}" fill="white"/><g font-family="Inter,Noto Sans SC,system-ui,sans-serif">']
    def text(self,x,y,s,size=17,color='#192638',bold=False):
        self.items.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}"'+(' font-weight="600"' if bold else '')+'>'+escape(s)+'</text>')
    def rect(self,x,y,w,h,fill='#f7f9fc',stroke='#dce4ef',rx=12):
        self.items.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}"/>')
    def box(self,x,y,w,h,lines,accent=False,warm=False):
        self.rect(x,y,w,h,'#fff7e8' if warm else '#edf3ff' if accent else '#f7f9fc','#ebcf9a' if warm else '#a9c2f5' if accent else '#dce4ef')
        for i,line in enumerate(lines):self.text(x+18,y+31+i*26,line,17 if i==0 else 14,'#245ce2' if accent and i==0 else '#52637d',i==0)
    def arrow(self,d,dashed=False):
        self.items.append(f'<path d="{d}" fill="none" stroke="#7086a8" stroke-width="2"'+(' stroke-dasharray="7 5"' if dashed else '')+' marker-end="url(#arrow)"/>')
    def save(self,name):
        (ROOT/'dist/assets'/name).write_text(''.join(self.items)+'</g></svg>')

d=SVG(1080,790,'ACT 训练与推理架构','训练专属CVAE编码器由示范和关节状态产生z；部署改为z=0。策略内部仍保留观测编码器与并行解码器。')
d.text(34,38,'ACT / 训练专属后验，与部署策略分开',24,bold=True)
d.text(34,66,'理解重绘 · 观测编码器在训练与推理中保留，CVAE 编码器仅训练使用。',14,'#64748b')
d.text(34,106,'01 / TRAINING ONLY',13,'#947132',True)
d.box(34,126,264,110,['示范样本','当前关节状态 q：14 维','示范动作块 A：k × 14'],warm=True)
d.box(356,126,284,110,['CVAE 编码器','[CLS] + q + A → k+2 tokens','Transformer → μ、σ'],warm=True)
d.box(698,126,348,110,['后验潜变量 z','重参数化采样：z = μ + σ ⊙ ε','训练：L1 重建 + β KL 正则'],warm=True)
d.arrow('M298 181H351');d.arrow('M640 181H693')
d.text(34,280,'02 / INFERENCE',13,'#137c79',True)
d.box(34,300,264,82,['不使用示范动作','z = 0（先验均值）'],accent=True)
d.text(360,327,'训练得到的 z 或推理时的零向量，',15,'#52637d')
d.text(360,354,'作为策略的一项条件，而非动作本身。',15,'#52637d')
d.arrow('M846 238V403H498V438',True);d.arrow('M298 342H322V403H498',True)
d.text(34,418,'03 / SHARED POLICY',13,'#245ce2',True)
d.box(34,444,264,136,['当前观测','4 × RGB 图像 → ResNet18','每视角 300 × 512 特征','当前双臂关节／夹爪 q'],accent=True)
d.box(356,444,284,136,['策略 Transformer encoder','1200 视觉 tokens + q + z','1202 × 512 的融合上下文','训练与测试都保留'],accent=True)
d.box(698,444,348,136,['策略 Transformer decoder','k 个固定位置查询（k × 512）','cross-attention 到观测表征','连续输出：k × 14，整块并行'],accent=True)
d.arrow('M298 508H351');d.arrow('M640 508H693')
d.box(356,626,284,84,['重叠动作块对齐当前时刻','时序集成 → 当前 14 维动作'])
d.box(698,626,348,84,['控制器执行当前目标','重新观察，下一步再预测新块'])
d.arrow('M872 582V603H498V623');d.arrow('M640 668H693')
d.arrow('M872 712V742H166V583')
d.text(344,762,'反馈循环：预测 k 步，不等于开环执行 k 步。',15,'#64748b')
d.save('act-architecture.svg')

d=SVG(1060,510,'ACT 重叠动作块对齐','k=4的教学例子：三份预测对同一执行时刻t=2的候选加权，执行当前一步。')
d.text(34,38,'ACT / 将不同观测的预测，对齐到同一执行时刻',23,bold=True)
d.text(34,66,'教学示意：k=4。单元格中的符号表示动作向量，颜色只用于区分预测产生时间。',14,'#64748b')
xs=[322+i*106 for i in range(6)]
for i,x in enumerate(xs):d.text(x+29,114,f't={i}',16,'#64748b',True)
for row,(start,color,stroke) in enumerate([(0,'#edf3ff','#a9c2f5'),(1,'#eff8f7','#99cdcb'),(2,'#fff7e8','#ebcf9a')]):
    y=140+row*76;d.text(34,y+29,f'观测 o{start} → 预测块',17,bold=True)
    for t in range(start,start+4):
        x=xs[t];d.rect(x,y,92,52,color,stroke,7);d.text(x+16,y+31,f'â{t}⁽{start}⁾',19,'#52637d')
d.items.append(f'<rect x="{xs[2]-7}" y="128" width="106" height="222" rx="10" fill="none" stroke="#245ce2" stroke-width="2" stroke-dasharray="6 4"/>')
d.arrow(f'M{xs[2]+46} 352V389')
d.box(360,394,398,75,['执行 t=2：融合 â2⁽0⁾、â2⁽1⁾、â2⁽2⁾','它们来自不同观测，但预测同一时刻。'],accent=True)
d.text(34,497,'只沿目标时刻的列集成；不把已执行的 t=0、t=1 动作混入当前动作。',15,'#64748b')
d.save('act-timeline.svg')
print('Rendered ACT: architecture, timeline, real results, simulation results, and ablations.')
