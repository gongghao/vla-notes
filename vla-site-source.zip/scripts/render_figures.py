"""Render the paper-reported ablation CSV to a reusable SVG with ReportLab Charts.
Run with a Python environment containing reportlab. No network or model required.
"""
import csv
from pathlib import Path
from reportlab.graphics.shapes import Drawing, Line, String
from reportlab.graphics.charts.barcharts import HorizontalBarChart
from reportlab.graphics import renderSVG
from reportlab.lib.colors import HexColor, white

root = Path(__file__).resolve().parents[1]
rows = list(csv.DictReader((root / 'dist/data/openvla-ablation.csv').open()))[::-1]
drawing = Drawing(820, 285)
chart = HorizontalBarChart()
chart.x, chart.y, chart.width, chart.height = 200, 45, 535, 180
chart.data = [[float(row['mean_success_percent']) for row in rows]]
chart.categoryAxis.categoryNames = ['Bridge + SigLIP only', 'Bridge only', 'OpenVLA']
chart.categoryAxis.labels.fontName = 'Helvetica'
chart.categoryAxis.labels.fontSize = 14
chart.categoryAxis.labels.fillColor = HexColor('#546780')
chart.categoryAxis.labels.boxAnchor = 'e'
chart.categoryAxis.labels.dx = -12
chart.categoryAxis.visibleTicks = False
chart.categoryAxis.visibleAxis = False
chart.valueAxis.valueMin, chart.valueAxis.valueMax, chart.valueAxis.valueStep = 0, 100, 25
chart.valueAxis.labels.fontSize = 12
chart.valueAxis.labels.fillColor = HexColor('#8291a6')
chart.valueAxis.strokeColor = HexColor('#e3e8f0')
chart.valueAxis.gridStrokeColor = HexColor('#e8edf5')
chart.valueAxis.visibleGrid = True
chart.valueAxis.visibleTicks = False
chart.barWidth, chart.groupSpacing = 24, 28
chart.bars.strokeColor = None
for i, color in enumerate(['#bac8de', '#8ca5cf', '#2e63df']):
    chart.bars[(0, i)].fillColor = HexColor(color)
drawing.add(chart)
for i, row in enumerate(rows):
    value, error = float(row['mean_success_percent']), float(row['standard_error_percentage_points'])
    y = chart.y + (i + .5) * chart.height / len(rows)
    x0, x1 = chart.x + (value-error)*chart.width/100, chart.x + (value+error)*chart.width/100
    for args in [(x0,y,x1,y),(x0,y-5,x0,y+5),(x1,y-5,x1,y+5)]:
        drawing.add(Line(*args,strokeColor=HexColor('#223e70'),strokeWidth=1.2))
    drawing.add(String(798,y-4,f'{value:.1f} ± {error:.1f}',fontName='Helvetica',fontSize=14,fillColor=HexColor('#334d72'),textAnchor='end'))
drawing.add(String(200,257,'MEAN SUCCESS (%)',fontName='Helvetica',fontSize=12,fillColor=HexColor('#8291a6')))
drawing.add(String(798,257,'Mean ± standard error',fontName='Helvetica',fontSize=12,fillColor=HexColor('#8291a6'),textAnchor='end'))
drawing.add(String(200,10,'OpenVLA v3 · Table 9 · 8 tasks, 10 trials per task',fontName='Helvetica',fontSize=12,fillColor=HexColor('#8291a6')))
renderSVG.drawToFile(drawing,str(root/'dist/assets/openvla-ablation.svg'))
print('Rendered dist/assets/openvla-ablation.svg from source CSV')
