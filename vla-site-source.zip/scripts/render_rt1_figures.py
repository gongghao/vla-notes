"""Render RT-1 paper-reported data as SVGs. Requires ReportLab; no model run."""
import csv
from pathlib import Path
from reportlab.graphics.shapes import Drawing, String
from reportlab.graphics.charts.barcharts import HorizontalBarChart
from reportlab.graphics import renderSVG
from reportlab.lib.colors import HexColor

ROOT = Path(__file__).resolve().parents[1]

def panel(drawing, rows, labels, key, x, y, width, height, title, colors):
    chart = HorizontalBarChart()
    chart.x, chart.y, chart.width, chart.height = x, y, width, height
    chart.data = [[float(r[key]) for r in rows[::-1]]]
    chart.categoryAxis.categoryNames = labels[::-1]
    chart.categoryAxis.labels.fontName = 'Helvetica'
    chart.categoryAxis.labels.fontSize = 12
    chart.categoryAxis.labels.fillColor = HexColor('#52637d')
    chart.categoryAxis.labels.boxAnchor = 'e'
    chart.categoryAxis.labels.dx = -10
    chart.categoryAxis.visibleTicks = False
    chart.categoryAxis.visibleAxis = False
    chart.valueAxis.valueMin, chart.valueAxis.valueMax, chart.valueAxis.valueStep = 0, 100, 25
    chart.valueAxis.labels.fontSize = 10
    chart.valueAxis.strokeColor = HexColor('#dce4ef')
    chart.valueAxis.gridStrokeColor = HexColor('#e8edf5')
    chart.valueAxis.visibleGrid = True
    chart.valueAxis.visibleTicks = False
    chart.barWidth, chart.groupSpacing = 17, 15
    chart.bars.strokeColor = None
    for i, color in enumerate(colors[::-1]):
        chart.bars[(0, i)].fillColor = HexColor(color)
    drawing.add(chart)
    for i, row in enumerate(rows[::-1]):
        v = float(row[key])
        drawing.add(String(x+v*width/100+6, y+(i+.5)*height/len(rows)-4,
                           f'{v:g}',fontName='Helvetica',fontSize=12,
                           fillColor=HexColor('#192638')))
    drawing.add(String(x-3,y+height+22,title,fontName='Helvetica-Bold',fontSize=13,fillColor=HexColor('#192638')))

rows = list(csv.DictReader((ROOT/'dist/data/rt1-results.csv').open()))
d = Drawing(830, 480)
for i, (key,title) in enumerate([('seen_percent','Seen tasks'),('unseen_percent','Unseen combinations'),('distractors_percent','Distractors'),('backgrounds_percent','Backgrounds')]):
    panel(d,rows,[r['model'] for r in rows],key,108+(i%2)*418,274-(i//2)*225,254,148,title,['#b2bfd6','#93a6c6','#6c85ae','#245ce2'])
d.add(String(108,14,'Success (%) | RT-1 v2, Table 2 | No uncertainty reported',fontName='Helvetica',fontSize=11,fillColor=HexColor('#64748b')))
renderSVG.drawToFile(d,str(ROOT/'dist/assets/rt1-results.svg'))

allrows = list(csv.DictReader((ROOT/'dist/data/rt1-data-ablation.csv').open()))
rows = [allrows[0],allrows[1],allrows[4]]
d=Drawing(830,280)
panel(d,rows,['100% tasks / 100% data','100% tasks / 51% data','75% tasks / 97% data'],'generalization_all_percent',213,53,522,162,'Generalization / All (%)',['#245ce2','#93a6c6','#137c79'])
d.add(String(213,13,'RT-1 v2, Table 7 | Author-reported aggregate',fontName='Helvetica',fontSize=11,fillColor=HexColor('#64748b')))
renderSVG.drawToFile(d,str(ROOT/'dist/assets/rt1-data-ablation.svg'))
print('Rendered RT-1 results and data-ablation figures from CSV.')
