# VLA Notes

面向 GitHub Pages 的静态学习站点。当前包含六个技术专题的主页，以及 OpenVLA 精读页。

## 本地预览

在本目录执行：

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

访问 `http://127.0.0.1:8765/`。无需安装前端依赖或构建。字体可从 Google Fonts 加载，不可用时回退到系统字体。

## 文件结构

```text
dist/
  index.html                       专题与论文入口
  papers/openvla/index.html         OpenVLA 精读内容
  assets/style.css                 共享样式、移动端布局
  assets/app.js                    目录、图像放大、流程切换、编码示例
  assets/openvla-architecture.svg   可编辑架构重绘
  assets/openvla-ablation.svg       从 CSV 生成的独立科学图表
  data/openvla-ablation.csv         论文 Table 9 数值及来源
```

## 增加论文

1. 以工作区的《VLA论文精读记录模板》组织内容；复制 `dist/papers/openvla/index.html` 到新的 `dist/papers/<slug>/index.html`。
2. 保留共用导航、样式和交互结构，更新标题、元数据、正文、来源与目录锚点。按论文选择重点模块；移除不适用的 OpenVLA 专属滑块、公式和表格。
3. 图存入 `assets/`，图表数值存入 `data/`。同时更新图的可访问描述与数据表，确保数值一致。
4. 在主页对应专题中，将论文名称改成链接；同步页面数量和侧栏入口。跨专题仍链接到同一篇主页面。
5. 本人阅读状态与整理状态分开；未运行实验不得记录为复现成功。数据图必须标明来源与实验协议。

第一版使用共享 CSS/JS 与独立 HTML，适合先确定阅读体验。论文数量增加后，可将导航和模板抽取到静态生成器，保留 URL、图表和内容分类。

## GitHub Pages

仓库：[gongghao/vla-notes](https://github.com/gongghao/vla-notes)。网站地址：[VLA Notes](https://gongghao.github.io/vla-notes/)。页面全部使用相对资源链接，同时兼容用户名站点和项目子路径。

仓库根目录应为本目录。在目标 GitHub 仓库的 Settings → Pages 中选择 GitHub Actions，然后运行提供的 `Deploy GitHub Pages` 工作流。工作流仅支持手动触发，上传 `dist/`，不自动发布每次推送。

## 内容版本

- 论文：arXiv:2406.09246v3（2024-09-05）。
- 代码：官方仓库 main，2026-10-08 检索；尚未固定 commit。
- 架构图：理解重绘，不是论文原图。
- 消融图：作者报告值，不是本地模型评测。
- 动作编码交互：复现源码的数值规则，基础词表大小示例取 32000。

## 验证

用浏览器检查主页到论文页、章节导航、架构放大与关闭、编码滑块、训练/推理切换、原始数据展开、窄屏侧栏。检查相对链接、图片和 CSV 资源可达；无需训练模型即可预览网站。

消融图由 `scripts/render_figures.py` 使用 ReportLab Charts 从 CSV 生成；更新数据后重跑脚本，并同步 HTML 数据表和说明。
