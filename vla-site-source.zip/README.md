# VLA Notes

面向 GitHub Pages 的静态学习站点。当前包含六个技术专题的主页，以及 OpenVLA、RT-1 两篇精读页。

## 本地预览

在本目录执行：

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

访问 `http://127.0.0.1:8765/`。无需安装前端依赖或构建。字体可从 Google Fonts 加载，不可用时回退到系统字体。

## 文件结构

```text
dist/
  index.html                       专题与论文入口
  papers/openvla/index.html         OpenVLA 精读内容
  papers/rt1/index.html             RT-1 精读内容（八个模块）
  assets/style.css                 共享样式、移动端布局
  assets/app.js                    目录、图像放大、流程切换、编码示例
  assets/openvla-architecture.svg   可编辑架构重绘
  assets/openvla-ablation.svg       从 CSV 生成的独立科学图表
  data/openvla-ablation.csv         论文 Table 9 数值及来源
  assets/rt1-architecture.svg       RT-1 架构与闭环控制重绘
  assets/rt1-results.svg            RT-1 四类评测图
  assets/rt1-data-ablation.svg      数据规模与任务多样性图
  data/rt1-*.csv                    RT-1 Tables 2、7、13 数值及来源
```

## 增加论文

1. 以工作区的《VLA论文精读记录模板》组织内容；复制 `dist/papers/openvla/index.html` 到新的 `dist/papers/<slug>/index.html`。
2. 保留共用导航、样式和交互结构，更新标题、元数据、正文、来源与目录锚点。按论文选择重点模块；移除不适用的 OpenVLA 专属滑块、公式和表格。
3. 图存入 `assets/`，图表数值存入 `data/`。同时更新图的可访问描述与数据表，确保数值一致。
4. 在主页对应专题中，将论文名称改成链接；同步页面数量和侧栏入口。跨专题仍链接到同一篇主页面。
5. 本人阅读状态与整理状态分开；未运行实验不得记录为复现成功。数据图必须标明来源与实验协议。

第一版使用共享 CSS/JS 与独立 HTML，适合先确定阅读体验。论文数量增加后，可将导航和模板抽取到静态生成器，保留 URL、图表和内容分类。

## GitHub Pages

仓库：[gongghao/vla-notes](https://github.com/gongghao/vla-notes)。网站地址：[VLA Notes](https://gongghao.github.io/vla-notes/)。页面全部使用相对资源链接，同时兼容用户名站点和项目子路径。

首次上线通过 GitHub 网页上传 `vla-site-source.zip` 完成。远程工作流只读取仓库，解压文件包中的 `dist/` 后发布；源文件包同时包含图表脚本和本文档。本地完整源文件保留在本目录。

更新网站时，将本目录的 `dist/`（保留目录层级）及源码说明重新打包为 `vla-site-source.zip`，在 GitHub 仓库中替换同名文件，然后在 Actions → Deploy GitHub Pages → Run workflow 中手动发布。推送或上传本身不会自动上线。

本地 Git 已保存源文件提交，但尚未具备 GitHub 推送凭据；远程首次提交由已登录的网页会话完成。以后配置 Git 推送后，可将源文件直接纳入远程仓库，并使用本地提供的 `dist/` 直接部署工作流。

## 内容版本

### OpenVLA

- 论文：arXiv:2406.09246v3（2024-09-05）。
- 代码：官方仓库 main，2026-10-08 检索；尚未固定 commit。
- 架构图：理解重绘，不是论文原图。
- 消融图：作者报告值，不是本地模型评测。
- 动作编码交互：复现源码的数值规则，基础词表大小示例取 32000。

### RT-1

- 论文：arXiv:2212.06817v2（2023-08-11；首次发表于 2022 年）。
- 代码：google-research/robotics_transformer，固定提交 `4569641b8111f3f402c32d8e24becd2a6e952ecc`。
- 内容包括 FiLM、TokenLearner、动作量化与损失、闭环延迟、实验与数据消融、OpenVLA 对照、代码走读与复现边界。
- 实验图使用论文报告值，CSV 保留表号与来源；原表未提供的不确定度不自行补绘。
- 动作编码交互使用公开源码的截断、255 倍缩放与向下取整规则；演示范围为 −1 到 1。
- 区分默认策略与动作自回归消融配置；注明正文及附录的任务统计口径差异。尚未运行模型或机器人实验。

## 验证

用浏览器检查主页到论文页、章节导航、架构放大与关闭、编码滑块、训练/推理切换、原始数据展开、窄屏侧栏。检查相对链接、图片和 CSV 资源可达；无需训练模型即可预览网站。

消融图由 `scripts/render_figures.py` 使用 ReportLab Charts 从 CSV 生成；更新数据后重跑脚本，并同步 HTML 数据表和说明。

RT-1 图表由 `scripts/render_rt1_figures.py` 使用同一图表库生成。
